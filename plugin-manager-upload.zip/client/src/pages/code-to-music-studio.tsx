import CodeToMusicStudio from '@/components/studio/CodeToMusicStudio';

export default function CodeToMusicStudioPage() {
  return <CodeToMusicStudio />;
}
