import AIAssistant from "@/components/studio/AIAssistant";

export default function AIAssistantPage() {
  return <AIAssistant />;
}
