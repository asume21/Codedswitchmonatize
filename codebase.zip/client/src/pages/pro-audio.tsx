import { ProAudioGenerator } from '@/components/studio/ProAudioGenerator';

export function ProAudio() {
  return <ProAudioGenerator />;
}

export default ProAudio;