import SongUploader from "@/components/studio/SongUploader";

export default function SongUploaderPage() {
  return <SongUploader />;
}
