import MelodyComposerV2 from '@/components/studio/MelodyComposerV2';

export default function MelodyComposerV2Page() {
  return <MelodyComposerV2 />;
}
