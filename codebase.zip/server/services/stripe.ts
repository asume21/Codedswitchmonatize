import Stripe from "stripe";
import type { IStorage } from "../storage";
import crypto from "crypto";
import { getCreditService, CREDIT_PACKAGES } from "./credits";

const STRIPE_SECRET_KEY = process.env.STRIPE_SECRET_KEY || "";
const STRIPE_WEBHOOK_SECRET = process.env.STRIPE_WEBHOOK_SECRET || "";
const APP_URL = process.env.APP_URL || "http://localhost:5000";
const PRICE_ID = process.env.STRIPE_PRICE_ID_PRO || "";

// Generate cryptographically secure activation key
function generateActivationKey(): string {
  const prefix = "CS"; // CodedSwitch
  const randomPart = crypto.randomBytes(16).toString('hex').toUpperCase();
  // Format: CS-XXXX-XXXX-XXXX-XXXX
  return `${prefix}-${randomPart.slice(0,4)}-${randomPart.slice(4,8)}-${randomPart.slice(8,12)}-${randomPart.slice(12,16)}`;
}

function getStripe(): Stripe {
  if (!STRIPE_SECRET_KEY) {
    throw new Error("STRIPE_SECRET_KEY is not set");
  }
  return new Stripe(STRIPE_SECRET_KEY, {
    apiVersion: "2025-08-27.basil",
  });
}

export async function createCheckoutSession(storage: IStorage, userId: string) {
  const stripe = getStripe();
  const user = await storage.getUser(userId);
  if (!user) throw new Error("User not found");
  if (!PRICE_ID) throw new Error("STRIPE_PRICE_ID_PRO is not set");

  let customerId = user.stripeCustomerId || undefined;
  if (!customerId) {
    const customer = await stripe.customers.create({
      email: user.email || undefined,
      metadata: { userId },
    });
    customerId = customer.id;
    await storage.updateUserStripeInfo(userId, { customerId });
  }

  const session = await stripe.checkout.sessions.create({
    mode: "subscription",
    customer: customerId,
    line_items: [{ price: PRICE_ID, quantity: 1 }],
    success_url: `${APP_URL}/billing/success?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${APP_URL}/billing/cancel`,
    metadata: { userId },
  });

  return { url: session.url };
}

export async function handleStripeWebhook(
  storage: IStorage,
  payload: Buffer,
  signature: string | string[] | undefined,
) {
  const stripe = getStripe();
  if (!STRIPE_WEBHOOK_SECRET) {
    throw new Error("STRIPE_WEBHOOK_SECRET is not set");
  }
  const sig = Array.isArray(signature) ? signature[0] : signature || "";

  const event = stripe.webhooks.constructEvent(payload, sig, STRIPE_WEBHOOK_SECRET);

  switch (event.type) {
    case "checkout.session.completed": {
      const session = event.data.object as Stripe.Checkout.Session;
      const customerId = (session.customer as string) || undefined;
      const subscriptionId = (session.subscription as string) || undefined;
      let userId = (session.metadata && (session.metadata as any).userId) || undefined;

      // Try to locate by metadata userId or fallback to customerId
      if (!userId && customerId) {
        const user = await storage.getUserByStripeCustomerId(customerId);
        userId = user?.id;
      }

      // Handle credit purchases (one-time payments)
      if (session.mode === 'payment' && userId) {
        const packageKey = session.metadata?.packageKey as keyof typeof CREDIT_PACKAGES;
        const credits = parseInt(session.metadata?.credits || '0');
        const paymentIntentId = session.payment_intent as string;

        if (packageKey && credits && paymentIntentId) {
          const creditService = getCreditService(storage);
          
          try {
            await creditService.purchaseCredits(
              userId,
              packageKey,
              paymentIntentId
            );
            console.log(`💳 Credits purchased via webhook: User ${userId}, +${credits} credits (${packageKey})`);
          } catch (error) {
            console.error(`❌ Failed to add credits for user ${userId}:`, error);
          }
        }
      }

      // Handle subscription checkouts
      if (userId && customerId && subscriptionId) {
        const sub = await stripe.subscriptions.retrieve(subscriptionId);
        const status = sub.status;
        const tier = status === "active" || status === "trialing" ? "pro" : "free";
        
        // Generate activation key for new pro subscribers
        const activationKey = generateActivationKey();
        console.log(`🔑 Generated activation key for user ${userId}: ${activationKey}`);
        
        // Update user with Stripe info AND activation key
        await storage.updateUserStripeInfo(userId, {
          customerId,
          subscriptionId,
          status,
          tier,
        });
        
        // Store the activation key in user record
        await storage.setUserActivationKey(userId, activationKey);
        
        // TODO: Send activation key via email to user
        console.log(`📧 TODO: Email activation key ${activationKey} to user`);
      }
      break;
    }

    case "customer.subscription.created":
    case "customer.subscription.updated":
    case "customer.subscription.deleted": {
      const sub = event.data.object as Stripe.Subscription;
      const customerId = (sub.customer as string) || undefined;
      const subscriptionId = sub.id;
      if (!customerId) break;
      const user = await storage.getUserByStripeCustomerId(customerId);
      if (!user) break;
      const status = sub.status;
      const tier = status === "active" || status === "trialing" ? "pro" : "free";
      await storage.updateUserStripeInfo(user.id, {
        customerId,
        subscriptionId,
        status,
        tier,
      });
      break;
    }

    default:
      // No-op for unhandled events
      break;
  }

  return { received: true };
}
